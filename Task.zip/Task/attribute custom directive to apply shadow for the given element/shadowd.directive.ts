import { Directive, ElementRef, Input,OnInit  } from '@angular/core';

@Directive({
  selector: '[appShadowd]'
})
export class ShadowdDirective implements OnInit{

  @Input() appShadowd:string ="10px 5px 5px black";

  constructor(private element: ElementRef) {
   }

   ngOnInit(){
      this.element.nativeElement.style.textShadow = this.appShadowd;
   }

}
