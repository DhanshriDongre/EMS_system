import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shadowc',
  templateUrl: './shadowc.component.html',
  styleUrls: ['./shadowc.component.css']
})
export class ShadowcComponent{

  

}
