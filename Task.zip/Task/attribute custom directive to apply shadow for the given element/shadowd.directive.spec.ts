import { ShadowdDirective } from './shadowd.directive';

describe('ShadowdDirective', () => {
  it('should create an instance', () => {
    const directive = new ShadowdDirective();
    expect(directive).toBeTruthy();
  });
});
