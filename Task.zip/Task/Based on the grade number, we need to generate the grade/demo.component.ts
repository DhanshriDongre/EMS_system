import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.scss']
})
export class DemoComponent {

  //public userObj1:any = {ename:"Smith", egrade: "1"};
  //public userObj2:any = {ename:"Scott", egrade: "2"};
  //public userObj3:any = {ename:"Ruth", egrade: "3"};
  //public userObj4:any = {ename:"ram", egrade: "4"};
  //public userObj5:any = {ename:"sham", egrade: "4"};
  //public userObj6:any = {ename:"haneesh", egrade: "1"};
  //public userObj7:any = {ename:"maneesh", egrade: "2"};
  
  public empArray1:any[]=[
    { name:"scott",grade:1},
    { name:"smith",grade:2},
    { name:"james",grade:1},
    { name:"adam",grade:4},
    { name:"ram",grade:1},
    { name:"seeta",grade:3},
    { name:"sham",grade:2},
    { name:"manish",grade:1},
   ];

  
  public empArray:any[]=[
    { name:"scott",grade:1},
    { name:"smith",grade:2},
    { name:"james",grade:1},
    { name:"adam",grade:4},
    { name:"ram",grade:1},
    { name:"seeta",grade:3},
    { name:"sham",grade:2},
    { name:"manish",grade:1},
   ];

}
